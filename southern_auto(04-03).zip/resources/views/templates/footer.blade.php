   <!-- Basic Form End-->
        <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="footer-copy-right">
                            <p>Copyright © 2018. All rights reserved.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!--    </div>-->

    <!-- jquery
		============================================ -->

<!--<script src="<% asset('/js/vendor/modernizr-2.8.3.min.js') %>"></script>-->
    <script src="<% asset('/js/vendor/jquery-1.12.4.min.js') %>"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<% asset('/js/bootstrap.min.js') %>"></script>
    <!-- wow JS
		============================================ -->
    <script src="<% asset('/js/wow.min.js') %>"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="<% asset('/js/jquery-price-slider.js') %>"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<% asset('/js/jquery.meanmenu.js') %>"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="<% asset('/js/owl.carousel.min.js') %>"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<% asset('/js/jquery.sticky.js') %>"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<% asset('/js/jquery.scrollUp.min.js') %>"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<% asset('/js/scrollbar/jquery.mCustomScrollbar.concat.min.js') %>"></script>
    <script src="<% asset('/js/scrollbar/mCustomScrollbar-active.js') %>"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="<% asset('/js/metisMenu/metisMenu.min.js') %>"></script>
    <script src="<% asset('/js/metisMenu/metisMenu-active.js') %>"></script>
    <!-- tab JS
		============================================ -->
    <script src="<% asset('/js/tab.js') %>"></script>
    <script src="<% asset('/js/c3-charts/d3.min.js') %>"></script>
    <script src="<% asset('/js/c3-charts/c3.min.js') %>"></script>
    <script src="<% asset('/js/c3-charts/c3-active.js') %>"></script>
   
    <!-- icheck JS
		============================================ -->
    <script src="<% asset('/js/icheck/icheck.min.js') %>"></script>
    <script src="<% asset('/js/icheck/icheck-active.js') %>"></script>
    <!-- plugins JS
		============================================ -->
    <script src="<% asset('/js/plugins.js') %>"></script>
    <!-- main JS
		============================================ -->
    <script src="<% asset('/js/main.js') %>"></script>
    <!-- tawk chat JS
		============================================ -->
<!--    <script src="<% asset('/js/tawk-chat.js') %>"></script>-->

 <!-- data table JS
		============================================ -->
    <script src="<% asset('/js/data-table/bootstrap-table.js') %>"></script>
    <script src="<% asset('/js/data-table/tableExport.js') %>"></script>
    <script src="<% asset('/js/data-table/data-table-active.js') %>"></script>
    <script src="<% asset('/js/data-table/bootstrap-table-editable.js') %>"></script>
    <script src="<% asset('/js/data-table/bootstrap-editable.js') %>"></script>
    <script src="<% asset('/js/data-table/bootstrap-table-resizable.js') %>"></script>
    <script src="<% asset('/js/data-table/colResizable-1.5.source.js') %>"></script>
    <script src="<% asset('/js/data-table/bootstrap-table-export.js') %>"></script>
    <script src="<% asset('/js/data-table/jspdf.min.js') %>"></script>
    <script src="<% asset('/js/data-table/jspdf.plugin.autotable.js') %>"></script>

  <!-- chosen JS
		============================================ -->
<script src="<% asset('/js/chosen/chosen.jquery.js') %>"></script>
<script src="<% asset('/js/chosen/chosen-active.js') %>"></script>


</body>

</html>