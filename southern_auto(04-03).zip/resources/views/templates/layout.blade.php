    @include('templates.header')
    @include('templates.top_menu')
    @include('templates.side_menu')
    @yield('content')
    @include('templates.footer')

